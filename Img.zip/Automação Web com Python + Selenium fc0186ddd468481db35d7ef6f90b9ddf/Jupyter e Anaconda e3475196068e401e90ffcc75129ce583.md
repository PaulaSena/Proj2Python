# Jupyter e Anaconda

Instalando o Jupyter - Pacote Anaconda para Programação em Python

# Google colab

Alternativa do Jupyter

integrado com o google drive

[https://colab.research.google.com/notebooks/welcome.ipynb?hl=pt-BR&authuser=1](https://colab.research.google.com/notebooks/welcome.ipynb?hl=pt-BR&authuser=1)

![Sem título.png](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Sem_ttulo.png)

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled.png)

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%201.png)

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%202.png)

se erro instalar o outro

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%203.png)

[]()

# Prompt Anaconda

![anaconda.png](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/anaconda.png)

# Jupyter

![Jupter.png](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Jupter.png)

[http://localhost:8888/tree](http://localhost:8888/tree)

Não Fechar o Jupyter 

## Criar uma nova pasta atraves do Jupyter

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%204.png)

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%205.png)

# Criando um notebook

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%206.png)

## Realizando um Print

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%207.png)

Celulas de Codgo e Celulas de Texto

## Markdown

![teste.jpg](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/teste.jpg)

### Pasta Download

![Untitled](Jupyter%20e%20Anaconda%20e3475196068e401e90ffcc75129ce583/Untitled%208.png)

# Sucesso 😀