# Instalando o Selenium

## Prompt Anaconda

## → pip install selenium

![Untitled](Instalando%20o%20Selenium%2066e5b02101424f179a7ba164045351a7/Untitled.png)